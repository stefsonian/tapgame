/* 

This class represents the Player

// TODO: code up the class

*/

import 'package:boloids/src/models/game.dart';


class Player {

String name;
int age;
String email;

Game game; // instance of current game being played


}